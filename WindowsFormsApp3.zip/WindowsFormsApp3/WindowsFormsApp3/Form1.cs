﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Assembly a = Assembly.GetExecutingAssembly();
            Type[] types = a.GetTypes();
            foreach (Type t in types)
            {
                System.Attribute[] attrs = System.Attribute.GetCustomAttributes(t);
                foreach (System.Attribute attr in attrs)
                {
                    if (attr is Author)
                    {
                        listBox1.Items.Add(t.Name);
                    }
                }
            }

        }
        object objectCreated;
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Assembly a = Assembly.GetExecutingAssembly();
            objectCreated = a.CreateInstance($"{a.GetName().Name}.{listBox1.SelectedItem}");
            Mostrar();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Assembly a = Assembly.GetExecutingAssembly();
            MethodInfo m = a.GetType($"{a.GetName().Name}.{listBox1.SelectedItem}").GetMethod(listBox2.SelectedItem.ToString());
            m.Invoke(objectCreated, new object[] { int.Parse(Interaction.InputBox("Número 1: ")) });
            Mostrar();
        }
        private void Mostrar()
        {
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            Assembly a = Assembly.GetExecutingAssembly();
            Type miTipo = a.GetType($"{a.GetName().Name}.{listBox1.SelectedItem}");
            MethodInfo[] arrayMetodos = miTipo.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);
            foreach (var m in arrayMetodos)
            {
                if (!m.IsSpecialName)
                {
                    listBox2.Items.Add(m.Name);
                }
            }
            PropertyInfo[] properties = miTipo.GetProperties();
            foreach (PropertyInfo property in properties)
            {
                listBox3.Items.Add(property.Name);
                listBox4.Items.Add(property.GetValue(objectCreated).ToString());
            }
        }
    }

    public class Author : System.Attribute
    {
        string name;
        public double version;

        public Author(string name)
        {
            this.name = name;
            version = 1.0;
        }

        public string GetName()
        {
            return name;
        }
    }

    [Author("F. Filosi")]
    public class Comprador
    {
        public Comprador() { CompradoComprador = 0; VendidoComprador = 0; }
        public int CompradoComprador { get; set; }
        public int VendidoComprador { get; set; }
        public void ComprarAVendedor(int param) { CompradoComprador += param; }
        public void VenderAVendedor(int param) { VendidoComprador += param; }
    }
    [Author("F. Filosi")]
    public class Vendedor
    {
        public Vendedor() { CompradoVendedor = 0; VendidoVendedor = 0; }
        public int CompradoVendedor { get; set; }
        public int VendidoVendedor { get; set; }
        public void ComprarAComprador(int param) { CompradoVendedor += param; }
        public void VenderAComprador(int param) { VendidoVendedor += param; }
    }
}
