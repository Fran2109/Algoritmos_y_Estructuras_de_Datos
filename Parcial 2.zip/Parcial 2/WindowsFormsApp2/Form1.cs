﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using Microsoft.VisualBasic;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        Type tipoOperaciones;
        object o;
        Assembly a;
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Enabled = false;
            tipoOperaciones = typeof(Operaciones);
            a = typeof(Operaciones).Assembly;
            MethodInfo[] methods = tipoOperaciones.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);
            foreach(MethodInfo mi in methods)
            {
                if(!mi.IsSpecialName)
                    listBox1.Items.Add(mi.Name);
            }
            o = a.CreateInstance(tipoOperaciones.FullName);
            PropertyInfo[] properties = tipoOperaciones.GetProperties();
            foreach(PropertyInfo pi in properties)
            {
                listBox2.Items.Add(pi.Name);
            }
            Mostrar();
        }
        private void Mostrar()
        {
            listBox3.Items.Clear();
            PropertyInfo[] properties = tipoOperaciones.GetProperties();
            foreach (PropertyInfo pi in properties)
            {
                listBox3.Items.Add(pi.GetValue(o));
            }
        }
        public class Operaciones
        {
            public int ultimoResultado { get; set; }
            public int anteUltimoResultado { get; set; }
            public int Sumar(int numero1, int numero2)
            {
                anteUltimoResultado = ultimoResultado;
                ultimoResultado = numero1 + numero2;
                return ultimoResultado;
            }
            public int Restar(int numero1, int numero2)
            {
                anteUltimoResultado = ultimoResultado;
                ultimoResultado = numero1 + numero2;
                return ultimoResultado;
            }
            public float Dividir(int numero1, int numero2)
            {
                anteUltimoResultado = ultimoResultado;
                ultimoResultado = numero1 / numero2;
                return ultimoResultado;
            }
            public float Multiplicar(int numero1, int numero2)
            {
                anteUltimoResultado = ultimoResultado;
                ultimoResultado = numero1 * numero2;
                return ultimoResultado;
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!button1.Enabled) button1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombreMetodo = listBox1.SelectedItem.ToString();
            MethodInfo method = tipoOperaciones.GetMethod(nombreMetodo);
            var resultado = method.Invoke(o, new object[]
            {
                int.Parse(Interaction.InputBox("Primer Numero")),
                int.Parse(Interaction.InputBox("Segundo Numero"))
            });
            MessageBox.Show($"El resultado es: {resultado}");
            Mostrar();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nombrePropiedad = listBox2.SelectedItem.ToString();
            PropertyInfo property = tipoOperaciones.GetProperty(nombrePropiedad);
            property.SetValue(o, int.Parse(Interaction.InputBox("Nuevo Valor")));
            var resultado = property.GetValue(o);
            MessageBox.Show($"El nuevo valor es {resultado}");
            Mostrar();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!button2.Enabled) button2.Enabled = true;
        }
    }
}
