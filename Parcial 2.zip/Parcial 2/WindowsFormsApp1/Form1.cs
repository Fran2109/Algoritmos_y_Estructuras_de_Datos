﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        List<Thread> threads;
        List<CancellationTokenSource> cancellationTokenSource;
        List<string> nombreProcesos;
        int procesos = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            threads = new List<Thread>();
            cancellationTokenSource = new List<CancellationTokenSource>();
            nombreProcesos = new List<string>();
            Form1.CheckForIllegalCrossThreadCalls = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
        }
        private TextBox createText(int i)
        {
            TextBox textBox1;
            textBox1 = new TextBox();
            SuspendLayout();
            textBox1.Location = new Point(200, 50 * (i-1) + 50);
            textBox1.Name = $"Proceso {i}";
            textBox1.Size = new Size(100, 20);
            textBox1.TabIndex = 0;
            Controls.Add(textBox1);
            ResumeLayout(false);
            PerformLayout();
            return textBox1;
        }
        private void Mostrar()
        {
            listBox1.Items.Clear();
            foreach(string nombre in nombreProcesos)
                listBox1.Items.Add(nombre);
            if (nombreProcesos.Count == 0)
            {
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Thread thread = new Thread(doThread);
            procesos++;
            TextBox textBox = createText(procesos);
            thread.Start(textBox);
            nombreProcesos.Add(textBox.Name);
            threads.Add(thread);
            Mostrar();
        }
        private void doThread(object obj)
        {
            CancellationTokenSource cs = new CancellationTokenSource();
            cancellationTokenSource.Add(cs);
            Random r = new Random();
            while (!cs.IsCancellationRequested)
            {
                (obj as TextBox).BackColor = Color.FromArgb(r.Next(0, 256), r.Next(0, 256), r.Next(0, 256));
                Thread.Sleep(500);
            }
            (obj as TextBox).Dispose();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!button2.Enabled && listBox1.SelectedItem != null) button2.Enabled = true;
            if (!button3.Enabled && listBox1.SelectedItem != null) button3.Enabled = true;
            if (!button4.Enabled && listBox1.SelectedItem != null) button4.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int indice = listBox1.SelectedIndex;
            cancellationTokenSource[indice].Cancel();
            threads.RemoveAt(indice);
            cancellationTokenSource.RemoveAt(indice);
            nombreProcesos.RemoveAt(indice);
            Mostrar();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int indice = listBox1.SelectedIndex;
            if(indice != -1)
            {
                threads[indice].Suspend();
                Mostrar();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int indice = listBox1.SelectedIndex;
            if (indice != -1)
            {
                threads[indice].Resume();
                Mostrar();
            }
        }

        private void listBox1_Leave(object sender, EventArgs e)
        {
            int indice = listBox1.SelectedIndex;
            if(indice == -1)
            {
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
            }
        }
    }
}
